La práctica no es correcta debido a la primera parte. La segunda es correcta.

Los valores que se utilizan en PID.adb, en concreto en el procedure controlar, no
estan bien calculados. En concreto Kd, Ki y Kd. A su vez, estos estan mal por los
valores que se obtienen en la pendiente.
La forma de sacarlos creo que es la correcta. Encontramos la pendiente máxima de la
curva, y donde interseccione con la temperatura K y la base, esos son los puntos
de referencia para T y L.
Sin embargo, creo que el problema viene a la hora de sacar la pendiente maxima. Esto
es arrastrado de la anterior, de la práctica 4.

Creo que, si hubiese disponido de la forma correcta de sacar las pendientes, el resto
hubiese salido bien. El cálculo de pendientes creo que es bastante sencillo, no se 
donde estará el problema. Se que es el problema ya que sí he representado las 
pendientes en excel, y no me convencen.

He adjuntado una foto de cómo he sacado los puntos que interseccionan, a partir de la
recta pendiente, en geogebra.