Hay 2 main.adb, que hacen referencia a dos archivos que se usan en el 6.1 y 6.2 
parar poder imprimir las pruebas de funcionamiento que hacemos, y que no se nos 
especifica el nombre.